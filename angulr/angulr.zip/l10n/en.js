{
  "header": {
    "navbar": {
      "UPLOAD": "Upload",
      "new": {
        "NEW": "New",
        "PROJECT": "Projects",
        "TASK": "Task",
        "USER": "User",
        "EMAIL": "Email"
      },
      "NOTIFICATIONS": "Notifications"
    }
  },
  "aside": {
    "nav": {
      "HEADER": "Navigation",
      "DASHBOARD": "控制台",
      "COLLECTION": "采集器",
      "CALENDAR": "日历",
      "EMAIL": "邮箱",
      "WIDGETS": "Widgets",
      "components": {
        "COMPONENTS": "Components",
        "ui_kits": {
          "UI_KITS": "UI Kits",
          "BUTTONS": "Buttons",
          "ICONS": "Icons",
          "GRID": "Grid",
          "BOOTSTRAP": "Bootstrap",
          "SORTABLE": "Sortable",
          "PORTLET": "Portlet",
          "TIMELINE": "Timeline",
          "VECTOR_MAP": "Vector Map"
        },
        "table": {
          "TABLE": "表格",
          "TABLE_STATIC": "静态表格",
          "DATATABLE": "数据表",
          "FOOTABLE": "Footable"
        },
        "form": {
          "FORM": "表单",
          "FORM_ELEMENTS": "Form elements",
          "FORM_VALIDATION": "Form validation",
          "FORM_WIZARD": "Form wizard"
        },
        "CHART": "图表",
        "pages": {
          "PAGES": "页面",
          "PROFILE": "Profile",
          "POST": "Post",
          "SEARCH": "Search",
          "INVOICE": "Invoice",
          "LOCK_SCREEN": "Lock screen",
          "SIGNIN": "Signin",
          "SIGNUP": "Signup",
          "FORGOT_PASSWORD": "Forgot password",
          "404": "404"
        }
      },
      "your_stuff": {
        "YOUR_STUFF": "Your Stuff",
        "PROFILE": "Profile",
        "DOCUMENTS": "Documents"
      }
    },
    "MILESTONE": "Milestone",
    "RELEASE": "Release"
  }
}