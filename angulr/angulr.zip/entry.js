window.$ = window.jQuery = require("./libs/jquery/jquery/dist/jquery-3.1.0.min.js");

require("./libs/jquery/bootstrap/dist/js/bootstrap.js");
